<!-- GENERATED FILE — do not edit by hand.
     Source: packages/react/src/nav.ts (via scripts/gen-agent-guide.ts)
     Regenerate: bun run gen:agent-guide  (checked by `bun run check`) -->

# zen-ui component catalogue

Each entry is the component's name and what it is *for*. Match the task to the
description, then import the name from your binding's package.

### Components

- **Button** — forwardRef, asChild, CVA variants × colors × sizes × shapes
- **Tooltip** — Radix Tooltip — positioning, dismissal, a11y
- **Popover** — Anchored panel; asChild trigger, side/align, separate anchor
- **Link** — Styled anchor; asChild for router links, external, disabled
- **Theme** — Scopes a theme to a subtree — a dark panel inside a light page; nests, no JS
- **Localization** — Translate every built-in string through LocaleProvider (any subset; the rest stays English), with plural rules per language; set the locale and currency numbers and dates use
- **DirectionProvider** — Right-to-left support — tells menus, tabs and sliders which way the page reads
- **MessagePopover** — Aggregated form validation grouped by severity; click a message to land on the field
- **Page + Bar** — The Page whole-screen container and the three-slot Bar row — the structural frame pieces
- **ColorPicker** — Swatch palette + the platform picker; hex in, hex out
- **Carousel** — Scroll-snap slide strip; every child is a slide, no autoplay
- **DropdownMenu** — Radix DropdownMenu — action menus, sub-menus, checkbox/radio items
- **ContextMenu** — Right-click menus at the pointer, from the keyboard (menu key, Shift+F10) and on long press
- **Separator** — Radix Separator — horizontal / vertical with decorative semantics
- **Switch** — Radix Switch — sizes, controlled / uncontrolled, form submission
- **Checkbox** — Radix Checkbox — native tri-state indeterminate, sizes
- **RadioGroup** — Radix RadioGroup — roving tabindex, arrow nav, form submission
- **Progress** — Radix Progress — sizes × colors, accessible value
- **Avatar** — Radix Avatar — image + initials fallback + stacked group
- **Badge** — Styled span with variants × colors, asChild for clickable
- **Skeleton** — Animated muted-box placeholder
- **Loading** — Animated spinner with sr-only label, color=current for buttons
- **Select** — Radix Select — keyboard nav, groups, form submission
- **Slider** — Radix Slider — single + range, vertical, keyboard control
- **ScrollArea** — Radix ScrollArea — custom scrollbars, both axes
- **Input + Textarea** — Plain styled <input> / <textarea>, all native attrs
- **Search** — Search field — magnifier, clear button, sm / md / lg; the affordance zen-ui inlined seven times
- **PasswordInput** — Password field with a show / hide toggle; every native input attribute passes through
- **NumberField** — Number input with −/+ stepper, clamp, decimal step
- **AmountField and QuantityField** — Amounts and quantities typed the way clerks do (1,25,000, 2.5L, 1.2Cr), formatted in the locale with the currency's own precision; LocaleProvider sets locale and currency once
- **DateInput** — Type a date the way clerks do (150326, t, +7) in the locale's order, with the calendar as a second way in; impossible dates are kept and flagged, never rolled over
- **DatePicker** — react-day-picker in a Radix Popover; inline Calendar too
- **InputOTP** — one input per digit, zero-dep; paste / autocomplete / a11y
- **MaskInput** — Fixed-template input — 99-9999, aa-99; the mask decides what may be typed
- **PhoneInput** — Composition: Select (country) + Input (number)
- **FAB** — Fixed-position Button wrapper + DropdownMenu for speed-dial
- **Form (RHF + Zod)** — react-hook-form + Zod resolver; FormField / FormItem / FormLabel / FormMessage
- **DataTable** — TanStack Table + Virtual; sorting, filtering, grouping, pinning, resizing, windowing
- **TreeTable** — Hierarchical rows; chevron indents inside the first column, filter keeps ancestors
- **Micro charts** — Sparkline-sized trend marks for a table cell or card — line, bar, bullet, delta, radial
- **TimerBadge / TestCountdownBar** — Exam clock from a deadline, not a decrementing number — colour thresholds, auto-expire hook, sticky bar
- **CodeEditor / IDEWindow** — Monaco wrapper — language, theme, read-only, Ctrl+Enter run hook; file list beside it
- **SpreadsheetGrid / SheetCalculator** — Editable cells with a real formula evaluator; errors render as errors, never a plausible number
- **ProctorStreamGrid / ProctorFlagOverlay** — Live candidate tiles with violation flags; displays streams, does not detect anything
- **ChunkUploader** — Large file in pieces — bounded retries, exponential backoff, pause and resume
- **DiagramCanvas / ArchitectureDraw** — Embedded diagrams.net editor over postMessage; draw.io XML in and out
- **DiffView** — What changed between two snapshots — added / removed / changed rows for an audit payload or a revision
- **DocumentViewer** — Show a scanned document — image or PDF, with zoom, fit, rotate and page count; the other half of FileUpload
- **Splitter** — Resizable panes — drag the divider, or arrow it; percentages, collapse, full WAI-ARIA separator
- **SortableList** — Reorder a list by dragging or entirely by keyboard; the app owns the order
- **Timeline** — Ordered list of events with a rail, markers, timestamps and date groups
- **UploadCollection** — The list of uploaded files — progress, rename, delete, retry; the result FileUpload has no view for
- **PlanningCalendar** — Resource-by-time grid — rows of people or rooms, appointments as blocks, day / week / month views
- **Gantt** — Project schedule — a collapsing task tree beside bars on a shared clock, with percent-complete fills, slip chips and dependency arrows; opens on a fit axis taken from the data, one tab stop with arrow-key grid navigation
- **ProductionSchedule** — Shop-floor schedule — work centres as rows holding many operations in lanes, changeovers drawn as time the machine is busy making nothing, finite capacity with overload, and a load histogram of booked over available WORKING hours
- **Pivot** — Drag-and-drop pivot builder; fields into zones, 2D-windowed grid
- **MediaTimeline** — Filmstrip trim track — draggable ranges over thumbnails, playhead, hover scrub, zoom; the app owns the state
- **Waveform** — Audio peaks lane with a draggable, trimmable clip window; shares a zoom with MediaTimeline so lanes align
- **Lazy options** — VirtualizedItems — drop-in windowing for huge option lists inside Combobox / Select
- **Combobox + Async** — cmdk-backed; sync `options` or async `onSearch` with debounced loading
- **TreeSelect** — Pick one node from a hierarchy (accounts, item groups): type to search, matches shown under their ancestors
- **LookupField** — Pick a row from a table of choices (items, customers): column headers, search across the columns in any order, server results, the chosen row returned whole; F4 opens the full search
- **Alert** — Inline semantic callout; compound Icon / Title / Description / Actions API
- **Dialog + AlertDialog** — Radix Dialog modal surface, plus AlertDialog for destructive confirmations
- **Shortcuts** — Kbd key caps, useShortcut with scopes, and a ? overlay listing every key: one chord string, spelled per platform
- **Toast** — Radix Toast — imperative toast() plus a Toaster viewport; variants and actions
- **FileUpload** — Drag-and-drop or browse; accept / max-size validation with per-file progress
- **Bound* fields** — BoundInput / BoundSelect / BoundSwitch — form-wired field wrappers, no boilerplate
- **Stepper** — Multi-step wizard for onboarding + journey apps (horizontal / vertical, linear / non-linear)
- **Banner** — Page-top persistent callout — verification reminders, maintenance windows, impersonation
- **EmptyState** — First-run / no-data / no-results surface; icon + title + description + actions
- **Tabs** — Radix-backed tabbed navigation; underline + pills variants, horizontal / vertical
- **Accordion** — Radix-backed collapsible sections; single + multiple expand modes
- **Collapsible** — One region that shows and hides — the single disclosure Accordion overserves
- **NativeSelect** — The platform <select>, styled to match Input — submits with no hidden input, opens as the OS picker on a phone
- **Label** — The <label> for a control outside a Form; required marker, sizes, peer-disabled dimming
- **Card** — Surface primitive + SelectableCard variant for goal pickers / plan selectors
- **Paper** — Document surface — reading measure, document typography, and a paper Dialog variant
- **StatCard** — A labelled figure — icon, delta, and somewhere to go
- **Tile** — A launchpad: tiles with a mark, a name and a live count, in a grid that is one tab stop with arrow keys
- **Sheet / Drawer** — Slide-in side panel on Radix Dialog; right / left / top / bottom
- **DateRangePicker** — Two-month side-by-side calendar in a Popover; range anchoring, controlled / uncontrolled
- **DynamicDateRange** — Semantic periods — "Last 7 days", "This quarter"; stores the question, not the answer
- **TagInput** — Type + Enter chip input; comma-paste splits, Backspace removes, per-tag validator, max-N
- **MultiCombobox** — Multi-select Combobox with chip trigger + overflow collapse + sync / async option loading
- **Rating** — 5-star rating input; hover preview, arrow-key nav, sm / md / lg, customizable max
- **NPS** — Net Promoter Score 0-10 strip with detractor / passive / promoter color buckets
- **Likert** — n-point attitudinal scale; segmented + stacked layouts, custom option sets
- **TimePicker** — Segmented HH:MM(:SS) input, 12h / 24h, AM/PM, auto-advance + arrow stepping
- **DateTimePicker** — Calendar + TimePicker in one Popover; preserves time-of-day on day changes
- **QRCode and Barcode** — Draw codes as SVG for screens and print: QR (the e-invoice's signed QR, gate passes; error correction L to H), Code 128, EAN-13 and Code 39, dark on light in every theme
- **QRScanner** — Camera-based QR / barcode scanner; native BarcodeDetector + custom-decoder escape hatch
- **NotificationsInbox** — Bell icon + popover panel; day-grouped feed with unread badge + per-row actions
- **Breadcrumb** — Hierarchical navigation path; collapsible ellipsis for deep trees
- **Pagination** — Page navigation with truncated ranges; usePaginationRange hook
- **Sidebar** — Collapsible navigation shell; provider + trigger + grouped menu

### Heavy / optional (lazy peer deps)

- **Chart (recharts)** — Lazy-loaded line / bar / area / pie / donut; recharts is an optional peer dep
- **RichText (jodit)** — Lazy-loaded WYSIWYG editor; jodit-pro-react is an optional peer dep
- **Map (leaflet)** — Lazy-loaded map with markers; leaflet + react-leaflet are optional peer deps
- **Camera (webcam)** — Lazy-loaded camera capture; react-webcam is an optional peer dep

### Zen-shaped

- **Icon** — zen-ui icon set (48 glyphs); inherits text colour, decorative by default
- **Object atoms** — ObjectStatus / ObjectNumber / ObjectIdentifier / ObjectMarker
- **Button family** — ToggleButton, SegmentedButton, SplitButton
- **Document tabs** — A workspace's open documents as closable, pinnable tabs with an all-tabs menu
- **Toolbar** — Actions that collapse into an overflow menu when they do not fit
- **Tree** — Hierarchical expandable list with full ARIA keyboard navigation

### Zen table ecosystem

- **SelectDialog** — Searchable list picker — single commits on click, multi commits on OK
- **ValueHelp** — F4 lookup dialog — the list picker plus a condition builder
- **ViewSettingsDialog** — Sort / group / filter settings; commits on OK
- **FilterBuilder** — Nested AND/OR conditions on any field as one serialisable object, for advanced list filters, report criteria and saved views; says in words what it filters
- **ViewManager** — Saved views beside the page title: name, save, save as, set as default, manage and share a list screen's filters, sort and columns as one object; storage stays the app's
- **FilterBar** — List Report filter area — fields, Go, and Adapt filters

### Zen app frame

- **PageHeader** — A heading with a back affordance and one action — the light one
- **SkipToContent** — Keyboard bypass — the first Tab reveals a link that jumps past the app chrome to the content (WCAG 2.4.1)
- **ShellBar** — Top-level app header — branding, search, actions, profile menu
- **FlexibleColumnLayout** — 1–3 column master-detail frame with responsive collapse
- **DynamicPage** — Title + header that snaps away on scroll; pinnable header
- **ObjectPageLayout** — Anchored sections with scroll-spy navigation

### Patterns (compositions, not exported components)

- **List Report** — FilterBar + DataTable — filter a set, read the result, act on a row
